from ctypes import *
from tkinter import *

so = cdll.LoadLibrary("./libcalc.so")


def get_input(entry, argu):
    entry.insert(END, argu)


def set_fun(entry):
    with open('./in.txt', 'w+', encoding='utf-8') as f:
        f.write(entry.get())
        print(entry.get())
    so.cal()


def calc(entry, entry2):
    print(str(entry.get()).encode())
    with open('./in.txt', 'w', newline='\n') as f:
        f.write(str(entry.get()))
    with open('./in.txt', 'r') as f:
        print(f.readline().encode())
    so.cal()
    with open('./out.txt', 'r') as f:
        entry2.select_clear()
        entry2.insert(END, f.readline())


def draw():
    root = Tk()
    root.title("计算器")
    root.resizable(0, 0)

    entry = Entry(root, justify="right")
    entry.grid(row=0, column=0, columnspan=4)
    entry2 = Entry(root, justify="right")
    entry2.grid(row=1, column=0, columnspan=4)

    Button(text='1', command=lambda: get_input(entry, '1')).grid(row=2, column=0, )
    Button(text='2', command=lambda: get_input(entry, '2')).grid(row=2, column=1)
    Button(text='3', command=lambda: get_input(entry, '3')).grid(row=2, column=2)
    Button(text='4', command=lambda: get_input(entry, '4')).grid(row=2, column=3)

    Button(text='5', command=lambda: get_input(entry, '5')).grid(row=3, column=0)
    Button(text='6', command=lambda: get_input(entry, '6')).grid(row=3, column=1)
    Button(text='7', command=lambda: get_input(entry, '7')).grid(row=3, column=2)
    Button(text='8', command=lambda: get_input(entry, '8')).grid(row=3, column=3)

    Button(text='+', command=lambda: get_input(entry, '+')).grid(row=4, column=0)
    Button(text='-', command=lambda: get_input(entry, '-')).grid(row=4, column=1)
    Button(text='*', command=lambda: get_input(entry, '*')).grid(row=4, column=2)
    Button(text='/', command=lambda: get_input(entry, '/')).grid(row=4, column=3)

    Button(text='定义函数', command=lambda: set_fun(entry2)).grid(row=5, column=0, columnspan=2)
    Button(text='计算结果', command=lambda: calc(entry, entry2)).grid(row=5, column=2, columnspan=2)
    root.mainloop()


if __name__ == '__main__':
    draw()
# calc()
