from ctypes import *
dll = CDLL("fb3-3.tab.dll")
r = ''
dll.Calculation('1+1',r)
print(r)
