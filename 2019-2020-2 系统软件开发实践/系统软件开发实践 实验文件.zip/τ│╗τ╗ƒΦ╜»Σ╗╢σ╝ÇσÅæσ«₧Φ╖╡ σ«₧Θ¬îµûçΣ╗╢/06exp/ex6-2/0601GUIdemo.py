import os
import time
import tkinter as tk

from tkinter import filedialog


class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        # self.master.geometry('600x500')
        self.pack()
        self.create_widgets()

    def get_time(self):
        return '[{}]: '.format(time.strftime(
            "%Y-%m-%d %H:%M:%S", time.localtime()))

    def get_output(self, string):
        self.output_text["state"] = tk.NORMAL
        self.output_text.insert(tk.END, self.get_time() + string + '\n')
        self.output_text["state"] = tk.DISABLED
        self.output_text.see(tk.END)

    def open_file(self):
        self.file_path = filedialog.askopenfilename()
        self.text.delete('1.0', tk.END)
        try:
            with open(self.file_path, 'r+', encoding='utf-8') as f:
                self.text.insert(tk.END, f.read())
            self.get_output('文件打开成功')
        except FileNotFoundError as e:
            print(e)
            self.get_output('文件打开失败')

    def save_file(self):
        try:
            with open(self.file_path, 'w+', encoding='utf-8') as f:
                f.write(self.text.get('1.0', tk.END))
            self.get_output('文件保存成功')
        except FileNotFoundError as e:
            self.text.delete('1.0', tk.END)
            print(e)

    def compile_shell(self):
        os.system('./build.sh')
        self.get_output('文件编译成功')

    def run_shell(self):
        os.system('./a.out')
        with open('out.txt', 'r+', encoding='utf-8') as f:
            temp_str = f.read()
            self.get_output('输出结果：\n'+temp_str)

    def create_widgets(self):
        # 菜单栏
        self.menubar = tk.Menu(self)
        # 文件读取子菜单
        self.filemenu = tk.Menu(self.menubar, tearoff=0)
        self.filemenu.add_command(label='打开', command=self.open_file)
        self.filemenu.add_command(label='保存', command=self.save_file)
        # shell命令子菜单
        self.shellmenu = tk.Menu(self.menubar, tearoff=0)
        self.shellmenu.add_command(label='编译', command=self.compile_shell)
        self.shellmenu.add_command(label='运行', command=self.run_shell)
        # 菜单栏根菜单
        self.menubar.add_cascade(label='文件', menu=self.filemenu)
        self.menubar.add_cascade(label='命令', menu=self.shellmenu)
        self.master.config(menu=self.menubar)

        self.frame1 = tk.Frame(self)
        self.text = tk.Text(self.frame1, width=80, height=20)
        self.scroll = tk.Scrollbar(self.frame1, command=self.text.yview)
        self.text.configure(yscrollcommand=self.scroll.set)
        self.text.pack(fill=tk.X, side=tk.LEFT)
        self.scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.frame1.pack(fill=tk.X)

        self.frame2 = tk.Frame(self)
        self.output_text = tk.Text(self.frame2, height=10)
        self.output_scroll = tk.Scrollbar(
            self.frame2, command=self.output_text.yview)
        self.output_text.configure(yscrollcommand=self.output_scroll.set)
        self.output_text.pack(fill=tk.X, side=tk.LEFT)
        self.output_text["state"] = tk.DISABLED
        self.output_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.frame2.pack(fill=tk.X)


root = tk.Tk()
app = Application(master=root)
app.mainloop()
