bison -d fb4-1.y
flex fb4-1.l 
gcc lex.yy.c fb4-1.tab.c fb4-1funcs.c -lm
