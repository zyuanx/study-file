

/**/
void main()
{
	int i = 0;
	int j = 0;
	
}

void t1()
{
	int i = 0;
}
/**/

typedef unsigned int uint;

uint xx;
uint yy;


