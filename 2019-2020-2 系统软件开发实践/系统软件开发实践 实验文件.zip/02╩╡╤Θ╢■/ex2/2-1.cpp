#include <iostream>
using namespace std
int main()
{
	// comment1
    cout<<"Hello! "<<endl;
	/*
	comment2 
	123 456 int
	*/
    cout<<"Welcome to c++! "<<endl;
return 0;
}