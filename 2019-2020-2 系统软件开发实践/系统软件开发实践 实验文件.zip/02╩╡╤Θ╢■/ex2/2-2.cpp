#include <iostream>
using namespace std
int main(){
    int a 123 023 0x23ff 34830.34E+4
    char 'a'
    // comment1
    /*
    comment2 
    123 456 int
    */
    
    cout<<"Welcome to c++! " endl;
    return 0;
}
