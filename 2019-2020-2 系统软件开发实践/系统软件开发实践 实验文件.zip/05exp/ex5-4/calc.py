from ctypes import cdll
from tkinter import *
import tkinter.messagebox as mesb

# Ubuntu使用此方法
# so = cdll.LoadLibrary("./libcalc.so")

so = cdll.LoadLibrary("./lex.yy.dll")
root = Tk()


def clear_text(t1, t2):
    t1.delete('1.0', END)

    t2["state"] = NORMAL
    t2.delete('1.0', END)
    t2["state"] = DISABLED


def delete_text(t1):
    s = t1.get('1.0', END)
    print(s)
    t1.delete('1.0', END)
    t1.insert(END, s[:-2])


def input_text(t1, fac):
    t1.insert(END, fac)


def calc(t1, t2):
    ast = t1.get('1.0', END).split('\n')
    with open('./out.txt', 'w') as f:
        f.write('')
    while ast[-1] == '':
        ast = ast[:-1]
    with open('./in', 'w') as f:
        f.write(ast[-1] + '\n')
    so.cal()
    if ast[-1][0] == 'c':
        window2 = Toplevel(root,width=110,height=50)
        window2.resizable(0, 0)
        with open('./out.txt', 'r') as f:
            content = f.read()
            # print(content)
            t = Text(window2,width=110,height=50)
            t.pack()
            t.insert(END, content)
            t["state"] = DISABLED
            # label = Label(, ,width=100,height=40)
    with open('./out', 'r') as f:
        # t1.insert(END, '\n')
        t1.see(END)
        t2["state"] = NORMAL
        t2.insert(END, f.readline(), 'right')
        t2.see(END)
        t2["state"] = DISABLED


def draw():
    root.title("flex&bison")
    root.update()
    root.resizable(0, 0)

    text1 = Text(root, height=4, width=12, font=('', 14))
    text1.pack(fill=X, padx=2, pady=2, ipadx=2, ipady=2, )

    text2 = Text(root, height=2, width=12, font=('', 14))
    text2.tag_configure("right", justify='right')
    text2.pack(fill=X, padx=2, pady=2, ipadx=2, ipady=2, )
    text2["state"] = DISABLED
    frame0 = Frame(root)
    frame0.pack(fill=BOTH)
    frame0.update()

    Button(frame0, text='C', command=lambda: clear_text(
        text1, text2), width=9, height=2).pack(side=LEFT)
    Button(frame0, text='退格', command=lambda: delete_text(
        text1), width=9, height=2).pack(side=LEFT)
    Button(frame0, text='(', command=lambda: input_text(
        text1, '('), width=9, height=2).pack(side=LEFT)
    Button(frame0, text=')', command=lambda: input_text(
        text1, ')'), width=9, height=2).pack(side=LEFT)

    frame1 = Frame(root)
    frame1.pack()
    Button(frame1, text='7', command=lambda: input_text(
        text1, '7'), width=9, height=2).pack(side=LEFT)

    Button(frame1, text='8', command=lambda: input_text(
        text1, '8'), width=9, height=2).pack(side=LEFT)
    Button(frame1, text='9', command=lambda: input_text(
        text1, '9'), width=9, height=2).pack(side=LEFT)
    Button(frame1, text='/', command=lambda: input_text(text1, '/'),
           width=9, height=2).pack(side=LEFT)

    frame2 = Frame(root)
    frame2.pack()

    Button(frame2, text='4', command=lambda: input_text(
        text1, '4'), width=9, height=2).pack(side=LEFT)
    Button(frame2, text='5', command=lambda: input_text(
        text1, '5'), width=9, height=2).pack(side=LEFT)
    Button(frame2, text='6', command=lambda: input_text(
        text1, '6'), width=9, height=2).pack(side=LEFT)
    Button(frame2, text='*', command=lambda: input_text(text1, '*'),
           width=9, height=2).pack(side=LEFT)
    frame3 = Frame(root)
    frame3.pack()
    Button(frame3, text='1', command=lambda: input_text(
        text1, '1'), width=9, height=2).pack(side=LEFT)
    Button(frame3, text='2', command=lambda: input_text(
        text1, '2'), width=9, height=2).pack(side=LEFT)
    Button(frame3, text='3', command=lambda: input_text(
        text1, '3'), width=9, height=2).pack(side=LEFT)

    Button(frame3, text='-', command=lambda: input_text(text1, '-'),
           width=9, height=2).pack(side=LEFT)
    frame4 = Frame(root)
    frame4.pack()
    Button(frame4, text='0', command=lambda: input_text(
        text1, '0'), width=9, height=2).pack(side=LEFT)
    Button(frame4, text='.', command=lambda: input_text(
        text1, '.'), width=9, height=2).pack(side=LEFT)
    Button(frame4, text='+', command=lambda: input_text(text1, '+'),
           width=9, height=2).pack(side=LEFT)
    Button(frame4, text='=', command=lambda: calc(
        text1, text2), width=9, height=2).pack(side=LEFT)

    Label(root, text='By：07172757 李治远').pack(pady=5)
    root.mainloop()


if __name__ == '__main__':
    draw()
