from ctypes import *

so = cdll.LoadLibrary("./libcalc.dll")
so.cal()


