main(){
	int a,b;
	if a;
	else b;
	return 0;
}